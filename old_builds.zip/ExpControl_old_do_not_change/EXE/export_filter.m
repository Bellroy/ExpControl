

M = fspecial('gaussian',10,1.5)

csvwrite('gaussian_filter.txt',M)
