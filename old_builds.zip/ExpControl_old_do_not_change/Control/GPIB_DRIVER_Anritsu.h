



t_gpibDevice *GPIB_deviceParameters_AnritsuMG3692A (void);
