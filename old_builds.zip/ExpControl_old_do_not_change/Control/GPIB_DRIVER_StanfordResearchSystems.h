

t_gpibDevice *GPIB_deviceParameters_SRS_PS350(void);

t_gpibDevice *GPIB_deviceParameters_SRS_SG384(void);   


