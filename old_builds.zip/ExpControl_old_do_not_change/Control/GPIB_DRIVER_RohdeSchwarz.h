



t_gpibDevice *GPIB_deviceParameters_RohdeSchwarzSML02 (void);

t_gpibDevice *GPIB_deviceParameters_RohdeSchwarzSMY01 (void);    
t_gpibDevice *GPIB_deviceParameters_RohdeSchwarzSMY02 (void);
