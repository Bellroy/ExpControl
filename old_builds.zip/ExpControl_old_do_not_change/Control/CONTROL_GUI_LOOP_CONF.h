#ifndef CONTROL_GUI_LOOP_CONF_H
#define CONTROL_GUI_LOOP_CONF_H

void sendConfFile (void);

#endif
