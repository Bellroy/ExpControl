
t_gpibDevice *GPIB_deviceParameters_BNC575 (void);
int GPIB_transmitCommand_BNC575 (t_sequence *s, t_gpibCommand *g, int dummy, int dummy2); 
