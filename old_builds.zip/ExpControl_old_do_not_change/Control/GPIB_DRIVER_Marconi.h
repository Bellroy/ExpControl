



t_gpibDevice *GPIB_deviceParameters_Marconi2030 (void);
