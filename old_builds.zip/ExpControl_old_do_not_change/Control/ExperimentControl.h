#ifndef EXPERIMENT_CONTROL_H
#define EXPERIMENT_CONTROL_H

#include <WinSock2.h>
#include <WS2tcpip.h>

SOCKET ConnectSocket;

#endif
