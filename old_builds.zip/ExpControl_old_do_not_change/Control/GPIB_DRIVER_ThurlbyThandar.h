

t_gpibDevice *GPIB_deviceParameters_ThurlbyThandarPL330DP(void);

int GPIB_transmitVoltage_PL330DP (int gpibAddress, double voltage, double current, int channel, int switchOn);






